package com.cognizant.dao;

import com.cognizant.helper.ConnectionManager;

public class JDBCProductDAOImpl implements ProductDAO{
	
	private ConnectionManager manager=new ConnectionManager();

	@Override
	public void showProduct(String productName) {
		// TODO Auto-generated method stub
		
		
		
	}
	

}
