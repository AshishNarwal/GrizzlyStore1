package com.cognizant.dao;

public interface ProductDAO {
	
	public void showProduct(String productName);

}
